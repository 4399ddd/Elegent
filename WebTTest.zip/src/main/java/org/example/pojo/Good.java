package org.example.pojo;


import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.example.anno.State;
import org.hibernate.validator.constraints.URL;

import java.time.LocalDateTime;

@Data
public class Good {
    private Integer id;//主键ID
    @NotEmpty
    @Pattern(regexp = "^\\S{1,25}$")
    private String title;//商品标题
    @NotEmpty
    private String content;//商品内容
    @NotEmpty
    @URL
    private String coverImg;//封面图像
    @NotNull
    private Double price;//价格
    @NotEmpty
    private String address;//地址
    @State
    private String state;//发布状态 在售|停售(存为草稿)
    @NotNull
    private Integer categoryId;//商品分类id
    private Integer createUser;//创建人ID
    private LocalDateTime createTime;//创建时间
    private LocalDateTime updateTime;//更新时间
}
