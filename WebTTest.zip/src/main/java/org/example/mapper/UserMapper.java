package org.example.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.example.pojo.User;

@Mapper
public interface UserMapper {
    //用户名查询重复
    @Select("select * from user where username = #{username}")
    User findByUserName(String username);

    //添加
    @Insert("insert into user(username,password,create_time,update_time)" +
            " values(#{username},#{password},now(),now())")
    //md5String改为password
    void add(String username, String password);

    @Update("update user set nickname= #{nickname},email= #{email},update_time= #{updateTime} where id= #{id}")
    void update(User user);

    @Update("update user set userPic= #{avatarUrl},update_time= now() where id= #{id}")
    void updateAvatar(String avatarUrl,Integer id);
    @Update("update user set password= #{md5String},update_time=now() where id=#{id}")
    void updatePed(String md5String, Integer id);

    @Select("select * from userheart where userheart.email = #{mailbox}")
    User sentMailFindUser(String mailbox);

    //核心表
    @Insert("insert into user(username,password,create_time,update_time)" +
            " values(#{username},#{password},now(),now())")
    //md5String改为password
    void addHeart(String username, String password);
}
