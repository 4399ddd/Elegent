package org.example.mapper;

import org.apache.ibatis.annotations.*;
import org.example.pojo.Good;

import java.util.List;

@Mapper
public interface GoodMapper {
    //新增
    @Insert("insert into good(title, content, cover_img, price, address, category_id, create_user, create_time, update_time) " +
            "values(#{title},#{content},#{coverImg},#{price},#{address},#{categoryId},#{createUser},#{createTime},#{updateTime})")
    void add(Good good);
    //使用动态sql
    List<Good> list(Integer categoryId, String state,Double minPrice, Double maxPrice, String keyWords);

    //获取商品详情
    @Select("select * from good where id= #{id}")
    Good findById(Integer id);

   //更新商品
   @Update("update good set title=#{title},content=#{content},cover_img=#{coverImg},price=#{price},address=#{address},state=#{state},category_id=#{categoryId} where id = #{id}")
    void update(Good good);
    //删除商品
    @Delete("delete from good where id=#{id}")
    void delete(Integer id);
}
