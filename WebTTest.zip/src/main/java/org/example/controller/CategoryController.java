package org.example.controller;

import org.example.pojo.Category;
import org.example.pojo.Result;
import org.example.service.CategoryService;
import org.example.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/category")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;


    @PostMapping
    public Result add(@RequestBody @Validated(Category.Add.class) Category category){

        Map<String,Object> map = ThreadLocalUtil.get();
        String username=(String) map.get("username");
        Integer userId=(Integer)map.get("id");

        if(username.equals("ROOTMAX")&&userId.equals(1)) {
            categoryService.add(category);
            return Result.success("添加分类成功");
        }
        return Result.error("添加分类失败！");
    }

    @GetMapping
    public Result<List<Category>> list(){
        List<Category> cs= categoryService.list();
        return Result.success(cs);
    }

    @GetMapping("/detail")
    public Result<Category> detail(Integer id){
      Category c= categoryService.findById(id);
      return Result.success(c);
    }

    @PutMapping
    public Result update(@RequestBody @Validated(Category.Update.class) Category category){
        Map<String,Object> map = ThreadLocalUtil.get();
        String username=(String) map.get("username");
        Integer userId=(Integer)map.get("id");

        if(username.equals("ROOTMAX")&&userId.equals(1)) {

            categoryService.update(category);
            return  Result.success("修改分类成功");
        }

        return Result.error("修改分类失败");
    }

    //删除商品分类
    @DeleteMapping
    public Result delete(Integer id){
        Map<String,Object> map = ThreadLocalUtil.get();
        String username=(String) map.get("username");
        Integer userId=(Integer)map.get("id");

        if(username.equals("ROOTMAX")&&userId.equals(1)) {

            try{
                categoryService.delete(id);
                return Result.success("删除商品分类成功！");
            }catch(EmptyResultDataAccessException e){
                System.out.println("删除商品分类异常！");
                return Result.error("删除商品分类异常！");
            }
        }
        return Result.error("删除商品分类异常！");
    }
}
