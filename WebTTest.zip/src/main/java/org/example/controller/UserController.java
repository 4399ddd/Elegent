package org.example.controller;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import org.example.pojo.Result;
import org.example.pojo.User;
import org.example.service.UserService;
import org.example.utils.JwtUtil;
import org.example.utils.Md5Util;
import org.example.utils.ThreadLocalUtil;
import org.hibernate.validator.constraints.URL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/user")
@Validated
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    JavaMailSender sender;

    //传值user
    User webUser;


    @PostMapping("/register")
    public Result register(@Pattern(regexp = "^\\S{5,20}$") String username,
                           @Pattern(regexp = "^\\S{5,20}$") String password,
                           @NotNull @NotEmpty String email,
                           @NotNull @NotEmpty String confirm){

        ValueOperations<String,String> operations = stringRedisTemplate.opsForValue();

        if(!Boolean.TRUE.equals(operations.getOperations().hasKey(email))){
            return Result.error("该邮箱未申请验证码或验证码已过期!");
        }

        if(operations.get(email) == null|| !Objects.equals(operations.get(email), confirm)){
            return Result.error("验证码错误或已过期!");
        }
            //查询用户名是否重复
            User u=userService.findByUserName(username);
            if(u==null)
            {
                //没有占用-注册
                userService.register(username,password);
                return Result.success();
            }else
            {
                //占用
                return Result.error("用户名已被占用!");
            }
    }
//忘记密码sentMailFindUser
@PostMapping("/sentMailFindUser")
public Result sentMailFindUser(String mailbox){
   //找邮箱
   User userpoint= userService.sentMailFindUser(mailbox);
   if(userpoint==null)
   {
       return Result.error("该邮箱未注册!");
   }
   else
   {
       webUser=userpoint;
       SentMessage(mailbox);
       return Result.success("邮箱已找到,请在5分钟内输入验证码!");
   }
}

//正式发送
    @PostMapping("/sentUserMail")
    public Result sentUserMail(@NotNull @NotEmpty String email,
                               @NotNull @NotEmpty String confirm){

        ValueOperations<String,String> operations = stringRedisTemplate.opsForValue();
        if(!Boolean.TRUE.equals(operations.getOperations().hasKey(email))){
            return Result.error("该邮箱未申请验证码或验证码已过期!");
        }
        if(operations.get(email) == null|| !Objects.equals(operations.get(email), confirm)){
            return Result.error("验证码错误或已过期!");
        }

        SentMessage2(email,webUser);
        return Result.success("发送用户信息成功,请查收");
    }



//发mail
    @PostMapping("/sentMail")
    public Result sentMail(String mailbox){
        String orderCode=SentMessage(mailbox);
        return Result.success();
    }
    public String SentMessage(String mailbox){
        //SimpleMailMessage是一个比较简易的邮件封装，支持设置一些比较简单内容
        SimpleMailMessage message = new SimpleMailMessage();
        //设置邮件标题
        message.setSubject("Web商城系统注册验证码");
        //设置邮件内容
        String code=generateRandomVerificationCode();
        message.setText("尊敬的 Web商城系统用户：\n" +
                "\n" +
                "我们收到了一项请求，要求通过您的电子邮件地址访问您的邮箱："+mailbox+"。您的验证码为：\n" +code+
                "\n" +
                "如果您并未请求此验证码，则可能是他人正在尝试访问此邮箱。请勿将此验证码转发给或提供给任何人。\n" +
                "\n" +
                "此致\n" +
                "\n" +
                "徐星海管理员敬上");
        //设置邮件发送给谁，可以多个，这里就发给你的QQ邮箱
        message.setTo(mailbox);
        //邮件发送者，这里要与配置文件中的保持一致
        message.setFrom("haoxie80769@163.com");
        //OK，万事俱备只欠发送
        sender.send(message);
        storageRedis(mailbox,code);
        return code;
    }
    //发送用户信息
    public void SentMessage2(String mailbox,User user){
        //SimpleMailMessage是一个比较简易的邮件封装，支持设置一些比较简单内容
        SimpleMailMessage message = new SimpleMailMessage();
        //设置邮件标题
        message.setSubject("Web商城系统用户信息");
        //设置邮件内容
        message.setText("尊敬的 Web商城系统用户：\n" +
                "\n" +
                "我们收到了一项请求，要求通过您的电子邮件地址访问您的邮箱："+mailbox+
                "\n" +
                "您的用户名是"+user.getUsername()+
                "\n"+
                "您的密码是"+user.getPassword()+
                "\n"+
                "如果您并未请求此信息，则可能是他人正在尝试访问此邮箱。请勿将此信息转发给或提供给任何人。\n" +
                "\n" +
                "此致\n" +
                "\n" +
                "徐星海管理员敬上");
        //设置邮件发送给谁，可以多个，这里就发给你的QQ邮箱
        message.setTo(mailbox);
        //邮件发送者，这里要与配置文件中的保持一致
        message.setFrom("haoxie80769@163.com");
        //OK，万事俱备只欠发送
        sender.send(message);

    }

    //随机验证码6位
    public static String generateRandomVerificationCode() {
        return generateRandomVerificationCode(6);
    }

    public static String generateRandomVerificationCode(int length) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int randomNumber = random.nextInt(10); // 生成0-9之间的随机整数
            char randomChar = (char) ('0' + randomNumber); // 将随机整数转换为字符
            sb.append(randomChar);
        }
        return sb.toString();
    }

    //code存redis
    public void storageRedis(String key, String value){
        ValueOperations<String, String> operations = stringRedisTemplate.opsForValue();
     //   operations.set(key, value);
        operations.set(key, value,60*5, TimeUnit.SECONDS);
    }

    @PostMapping("/login")
    public Result<String> login(@Pattern(regexp = "^\\S{5,20}$") String username,@Pattern(regexp = "^\\S{5,20}$") String password){
        //根据用户名查找
        User loginUser=userService.findByUserName(username);

        if(loginUser==null){
            return Result.error("用户名错误！");
        }

        //判断是否存在  loginUser的password为密文
        if(Md5Util.getMD5String(password).equals(loginUser.getPassword())){
            //登录成功
            Map<String,Object> claims=new HashMap<>();
            claims.put("id",loginUser.getId());
            claims.put("username",loginUser.getUsername());
            String token = JwtUtil.genToken(claims);
            //把token存储到redis中
            ValueOperations<String, String> operations = stringRedisTemplate.opsForValue();
            operations.set(token,token,3, TimeUnit.HOURS);
            return Result.success(token);
        }

        //判断密码是否正确
        return  Result.error("密码错误!");
    }

    @GetMapping("/userInfo")
    public Result<User> userInfo(/*@RequestHeader(name = "Authorization") String token*/){
        //根据用户名查询用户
      /*  Map<String, Object> map = JwtUtil.parseToken(token);
        String username = (String)map.get("username");*/
        Map<String,Object> map=ThreadLocalUtil.get();
        String username=(String)map.get("username");

        User user = userService.findByUserName(username);
        return Result.success(user);

    }

    @PutMapping("/update")
    public Result update(@RequestBody @Validated User user) {
        userService.update(user);

      return Result.success("更新信息成功！");

    }

    @PatchMapping("/updateAvatar")
    public Result updateAvatar(@RequestParam  @URL String avatarUrl){
          userService.updateAvatar(avatarUrl);

          return Result.success("更新头像成功！");

    }

    @PatchMapping("/updatePwd")
    public Result updatePwd(@RequestBody Map<String,String> params,@RequestHeader("Authorization") String token){
        //1.校验参数

        String oldPwd = params.get("old_pwd");
        String newPwd = params.get("new_pwd");
        String rePwd = params.get("re_pwd");

        if(!StringUtils.hasLength(oldPwd)||!StringUtils.hasLength(newPwd)||!StringUtils.hasLength(rePwd))
        {
            return Result.error("缺少必要的参数");
        }


        //原密码是否正确
        //调用usrService根据用户名拿到密码,再和old_pwd比对
        Map<String,Object> map = ThreadLocalUtil.get();
        String username = (String)map.get("username");
        User loginUser = userService.findByUserName(username);
        if(!loginUser.getPassword().equals(Md5Util.getMD5String(oldPwd)))
        {
            return Result.error("原密码填写错误");
        }
        //newPwd和rePwd是否一样
        if(!rePwd.equals(newPwd)){
            return Result.error("两次填写的新密码不一样！");
        }
        //2.调用service完成密码更新
        userService.updatePwd(newPwd);
        //删除redis中对应的token
        ValueOperations<String, String> operations = stringRedisTemplate.opsForValue();
        operations.getOperations().delete(token);

        return  Result.success("密码修改成功！");


    }

}
