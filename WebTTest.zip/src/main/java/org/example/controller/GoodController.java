package org.example.controller;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import org.example.pojo.Category;
import org.example.pojo.Good;
import org.example.pojo.PageBean;
import org.example.pojo.Result;
import org.example.service.GoodService;
import org.example.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;


@RestController
@RequestMapping("/good")
public class GoodController {
    @Autowired
    private GoodService goodService;


    @PostMapping
    public Result add(@RequestBody @Validated Good good){
        goodService.add(good);
        return Result.success("添加商品成功！");
    }

    @GetMapping
    public Result<PageBean<Good>> list(
            Integer pageNum,
            Integer pageSize,
            @RequestParam(required = false) Integer categoryId,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) String keyWords

    ){
    PageBean<Good> pb= goodService.list(pageNum,pageSize,categoryId,state,minPrice,maxPrice,keyWords);
    return Result.success(pb);
    }



    //获取商品详情
    @GetMapping("/detail")
    public Result<Good> detail(Integer id){
        Good good=goodService.findById(id);
        return Result.success(good);

    }

    //更新商品 权限
    @PutMapping
    public Result update(@RequestBody @Validated Good good){
        Map<String,Object> map = ThreadLocalUtil.get();
        Integer userId=(Integer)map.get("id");
        //userId.equals(good.getCreateUser())结合user表
        try{
          Good goodFind= goodService.findById(good.getId());
           Integer mygoodid=goodFind.getCreateUser();
           if(userId.equals(mygoodid)||userId.equals(1)){
               goodService.update(good);
               return  Result.success("修改商品成功");
           }

            return Result.error("您未拥有此商品修改权限！");

        }catch (RuntimeException e){
            System.out.println(e.toString());
            return Result.error("商品修改权限异常！");

        }




    }
    //批量删除
    @DeleteMapping("/deleteselect")
    public Result deleteSelect(@RequestParam List<Integer> ids){
     //   System.out.println(ids);
        try{
        goodService.deleteSelect(ids);
        return Result.success("删除商品成功！");
        }catch(EmptyResultDataAccessException e){
            System.out.println("删除商品异常！");
            return Result.error("删除商品异常！");
        }
    }



    //删除商品 权限
    @DeleteMapping
    public Result delete(Integer id,String filename){
        Map<String,Object> map = ThreadLocalUtil.get();
        Integer userId=(Integer)map.get("id");
        Good good=goodService.findById(id);
        if(userId.equals(good.getCreateUser()))
        {
            try{
                goodService.delete(id);
                deleteFile(filename);
                return Result.success("删除商品成功！");
            }catch(EmptyResultDataAccessException e){
                System.out.println("删除商品异常！");
                return Result.error("删除商品异常！");
            }

        }


        return Result.error("删除商品异常！");

    }
      public void deleteFile(String objectName) {
        // 创建OSSClient实例

          String endpoint = "oss-cn-beijing.aliyuncs.com";
          String accessKeyId="LTAI5tEP1mDUbxxFpUggD3Dk";
          String accessKeySecret="xUHZyZ9KPWdtoRCwyYr9ta2gOntnip";
          String bucketName = "hmleadnews9999xxh";

        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);

        // 删除文件
        ossClient.deleteObject(bucketName, objectName);

        // 关闭OSSClient
        ossClient.shutdown();
    }

}
