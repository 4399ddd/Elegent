package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Hello world!
 *
 */
@SpringBootApplication
public class WebTTestApplication
{
    public static void main( String[] args )
    {
        SpringApplication.run(WebTTestApplication.class,args);
    }
}
