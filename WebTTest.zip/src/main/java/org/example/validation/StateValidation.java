package org.example.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.example.anno.State;

//<给哪个注解提供校验规则,校验的数据类型>
public class StateValidation implements ConstraintValidator<State,String> {
    //value 将来要校验的数据 isValid return False不通过，true通过
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        //提供校验规则
        if(value==null){
            return false;
        }
        if(value.equals("停售")||value.equals("在售"))
        {
            return true;
        }
        return false;
    }
}
