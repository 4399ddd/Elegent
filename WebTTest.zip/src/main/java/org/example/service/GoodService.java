package org.example.service;

import org.example.pojo.Good;
import org.example.pojo.PageBean;

public interface GoodService {
    //新增商品
    void add(Good good);

    //条件页表分类查询
    PageBean<Good> list(Integer pageNum, Integer pageSize, Integer categoryId, String state,Double minPrice, Double maxPrice, String keyWords);

    //获取商品详情
    Good findById(Integer id);

    //更新商品
    void update(Good good);

    //删除商品
    void delete(Integer id);
}
