package org.example.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.mapper.GoodMapper;
import org.example.pojo.Good;
import org.example.pojo.PageBean;
import org.example.service.GoodService;
import org.example.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Service
public class GoodServiceImpl implements GoodService {

    @Autowired
    private GoodMapper goodMapper;

    @Override
    public void add(Good good) {
        //补充属性值
        good.setCreateTime(LocalDateTime.now());
        good.setUpdateTime(LocalDateTime.now());

        Map<String,Object> map = ThreadLocalUtil.get();
        Integer userId = (Integer)map.get("id");
        good.setCreateUser(userId);

        goodMapper.add(good);
    }

    @Override
    public PageBean<Good> list(Integer pageNum, Integer pageSize, Integer categoryId, String state, Double minPrice, Double maxPrice,String keyWords) {
        //1.创建PageBean对象
        PageBean<Good> pb=new PageBean<>();

        //2.开启分页查询 PageHelper
        PageHelper.startPage(pageNum,pageSize);

        //3.调用mapper
        List<Good> as=goodMapper.list(categoryId,state,minPrice,maxPrice,keyWords);
        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Good> p= (Page<Good>) as;
        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());

        return pb;

    }

    //获取商品详情
    @Override
    public Good findById(Integer id) {
        Good good=goodMapper.findById(id);
        return good;

    }
    //更新商品
    @Override
    public void update(Good good) {
        good.setUpdateTime(LocalDateTime.now());
        goodMapper.update(good);

    }

    //删除商品
    @Override
    public void delete(Integer id) {
        goodMapper.delete(id);
    }
}
